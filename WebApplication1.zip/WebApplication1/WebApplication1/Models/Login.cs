﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Login
    {
        public string FirstName{ get; set; }
        public string LastName { get; set; }
        public int age { get; set; }
        public string city { get; set; }
        public string email { get; set; }
        public string password { get; set;}
        public string position { get; set; }
    }
}